<?php $__env->startSection('content'); ?>

<!-- This example requires Tailwind CSS v2.0+ -->
<div class="bg-white">
    <div class="grid items-center max-w-2xl grid-cols-1 px-4 py-24 mx-auto gap-y-16 gap-x-8 sm:px-6 sm:py-32 lg:max-w-7xl lg:px-8 lg:grid-cols-2">
      <div>
        <h2 class="text-3xl font-extrabold tracking-tight text-gray-900 sm:text-4xl">About Walkinroomaa</h2>
        <div id="timezone-display"></div>
        <?php if(Route::is('about')): ?>
        <script>
            $(document).ready(function(){
                let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
                $('#timezone-display').text(timezone);
            });
        </script>
        <?php endif; ?>

        <div id="date-display"></div>
        <div id="date-display2"></div>
        <script>
            $(document).ready(function(){
                let currentDate2 = new Date();
                $('#date-display2').text(currentDate2);
            });
        </script>
        <script>
        document.addEventListener('DOMContentLoaded', () => {
            let currentDate = new Date().toLocaleDateString();
            document.querySelector('#date-display').innerHTML = currentDate;
        });
        </script>
        <p class="mt-4 text-gray-500">The walnut wood card tray is precision milled to perfectly fit a stack of Focus cards. The powder coated steel divider separates active cards from new ones, or can be used to archive important task lists.</p>

        <dl class="grid grid-cols-1 mt-16 gap-x-6 gap-y-10 sm:grid-cols-2 sm:gap-y-16 lg:gap-x-8">
          <div class="pt-4 border-t border-gray-200">
            <dt class="font-medium text-gray-900">Origin</dt>
            <dd class="mt-2 text-sm text-gray-500">Designed by Good Goods, Inc.</dd>
          </div>

          <div class="pt-4 border-t border-gray-200">
            <dt class="font-medium text-gray-900">Material</dt>
            <dd class="mt-2 text-sm text-gray-500">Solid walnut base with rare earth magnets and powder coated steel card cover</dd>
          </div>

          <div class="pt-4 border-t border-gray-200">
            <dt class="font-medium text-gray-900">Dimensions</dt>
            <dd class="mt-2 text-sm text-gray-500">6.25&quot; x 3.55&quot; x 1.15&quot;</dd>
          </div>

          <div class="pt-4 border-t border-gray-200">
            <dt class="font-medium text-gray-900">Finish</dt>
            <dd class="mt-2 text-sm text-gray-500">Hand sanded and finished with natural oil</dd>
          </div>

          <div class="pt-4 border-t border-gray-200">
            <dt class="font-medium text-gray-900">Includes</dt>
            <dd class="mt-2 text-sm text-gray-500">Wood card tray and 3 refill packs</dd>
          </div>

          <div class="pt-4 border-t border-gray-200">
            <dt class="font-medium text-gray-900">Considerations</dt>
            <dd class="mt-2 text-sm text-gray-500">Made from natural materials. Grain and color vary with each item.</dd>
          </div>
        </dl>
      </div>
      
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Drive F\Website\Fresh2\walkinroom\resources\views\about.blade.php ENDPATH**/ ?>