<?php $__env->startSection('content'); ?>


<!--
  This example requires Tailwind CSS v2.0+

  This example requires some changes to your config:

  ```
  // tailwind.config.js
  module.exports = {
    // ...
    plugins: [
      // ...
      require('@tailwindcss/aspect-ratio'),
    ],
  }
  ```
-->
<div class="bg-white">
    <div class="max-w-2xl px-4 py-16 mx-auto sm:py-24 sm:px-6 lg:max-w-7xl lg:px-8">
      <h2 class="sr-only">Products</h2>

      <div class="grid grid-cols-1 gap-y-10 sm:grid-cols-2 gap-x-6 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8">
        <div class="grid grid-cols-12 col-span-12 gap-7">
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex flex-col items-start col-span-12 overflow-hidden shadow-sm rounded-xl md:col-span-6 lg:col-span-4">

                <?php
                    $arr=$room->image;
                    $yummy = json_decode($arr, true);
                ?>
                <a href="#_" class="block transition duration-200 ease-out transform hover:scale-110">
                    <img class="object-cover shadow-sm max-h-56" style="width:382px;" src="<?php echo e(Voyager::image( $yummy[0] )); ?>">
                </a>
                <div class="relative flex flex-col items-start px-6 bg-white border border-t-0 border-gray-200 py-7 rounded-b-2xl">
                    <div class="bg-indigo-400 absolute top-0 -mt-3 flex items-center px-3 py-1.5 leading-none w-auto inline-block rounded-full text-xs font-medium uppercase text-white inline-block">
                        <span><?php echo e($room->hotel->location->city); ?></span>
                    </div>
                    <h2 class="text-base font-bold sm:text-lg md:text-xl"><a href="<?php echo e(route('room',['id'=>$room->id, 0, 0])); ?>"><?php echo e(\Illuminate\Support\Str::limit($room->title, 20)); ?></a></h2>
                    <li class="flex items-center py-2 space-x-4 xl:py-3">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                    <span class="font-medium text-gray-500"><?php echo e($room->capacity); ?></span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    <span class="font-medium text-gray-500"><?php echo e($room->type->title); ?></span>
                    <span class="inline-flex rounded-md shadow-sm">
                        <a href="<?php echo e(route('room',['id'=>$room->id, 0, 0])); ?>" class="inline-flex items-center justify-center px-2 py-1 text-base font-medium leading-6 text-white whitespace-no-wrap bg-blue-600 border border-blue-700 rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Book Now
                        </a>
                        
                    </span>
                    </li>
                    <p class="mt-2 text-sm text-gray-500">Check out these inspiring workstations to get ideas on how to level-up your workstation.</p>

                    
                    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
        </div>


        <!-- More products... -->
      </div>
    </div>
  </div>


<!-- Modal toggle -->


  <!-- Main modal -->

<!-- Modal toggle -->


  <!-- Main modal -->
  





<!-- Section 7 -->






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Drive F\Website\Fresh2\walkinroom\resources\views/partials/roomlist.blade.php ENDPATH**/ ?>