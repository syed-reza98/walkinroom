<?php $__env->startSection('content'); ?>

    <!-- Section 2 hero -->
    <?php echo $__env->make('layouts.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Section 3 popular -->
    <?php echo $__env->make('partials.popular', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partials.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partials.list2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Section 4 testimonial -->
    




    <!-- Section 6 othersite -->
    

    <!-- Section 5 callaction -->
    <?php echo $__env->make('partials.callaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Section 7 -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Drive F\Website\Fresh2\walkinroom\resources\views/index.blade.php ENDPATH**/ ?>