
<section class="relative w-full bg-white">
    <div class="absolute w-full h-32 bg-gradient-to-b from-gray-100 to-white"></div>
    <div class="relative w-full px-5 py-8 mx-auto sm:py-10 md:py-14 md:px-10 max-w-7xl">
        
            <li class="flex items-center py-2 space-x-4 xl:py-3">
                <h1 class="mb-1 text-4xl font-extrabold leading-none text-gray-900 lg:text-5xl xl:text-5xl sm:mb-3">Choose your destination</h1>
                
            </li>
            <div class="grid grid-cols-1 mt-6 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="relative group">
                <div class="w-full overflow-hidden bg-gray-200 rounded-md min-h-80 aspect-w-1 aspect-h-1 group-hover:opacity-75 lg:h-80 lg:aspect-none">
                  <img src="<?php echo e(Voyager::image( $location->image )); ?>" alt="Front of men&#039;s Basic Tee in black." class="object-cover object-center w-full h-full lg:w-full lg:h-full">
                </div>
                <div class="flex justify-between mt-4">
                  <div>
                    <h2 class="text-base font-bold sm:text-lg md:text-xl"><a href="#_"><?php echo e($location->city); ?></a></h2>
                    
                    <h3 class="text-base font-medium text-indigo-600">
                      <a href="<?php echo e(route('loclist',['id'=>$location->id])); ?>">
                        <span aria-hidden="true" class="absolute inset-0"></span>
                        View All
                      </a>
                    </h3>
                    
                  </div>
                    <?php
                        $count = App\Hotel::where('location_id', $location->id)->count();
                    ?>
                    <li class="flex items-center py-2 space-x-1 xl:py-3">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" />
                        </svg>
                        <span class="font-medium text-gray-900">Hotels: <?php echo e($count); ?></span>
                        
                        
                    </li>

                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <!-- More products... -->
            
            </div>
    </div>
</section>


<?php /**PATH E:\Drive F\Website\Fresh2\walkinroom\resources\views\partials\list2.blade.php ENDPATH**/ ?>