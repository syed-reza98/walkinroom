

<img src="<?php echo e(asset('img/wlogo1.png')); ?>" alt="" width="210">
<?php /**PATH E:\Drive F\Website\Fresh2\walkinroom\resources\views/components/application-logo.blade.php ENDPATH**/ ?>