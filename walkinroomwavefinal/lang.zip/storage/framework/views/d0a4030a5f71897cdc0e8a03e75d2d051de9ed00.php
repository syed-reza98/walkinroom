<aside class="col-md-3 col-sm-4 col-xs-12 content-aside left_column sidebar-offcanvas">
    <span id="close-sidebar" class="fa fa-times"></span>
    

    <div class="clearfix module-pop">
        <h3>Latest Rooms</h3>
        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $arr=$room->image;
        $yummy = json_decode($arr, true);
        ?>
        <div class="clearfix item">
            <div class="image">
                <a href="tour-detail.html"><img src="<?php echo e(Voyager::image( $yummy[0] )); ?>" alt="Bougainvilleas on Lombard Street" style="width:370px; height:247px"></a>
            </div>
            <div class="content">
                <h4><a href="tour-detail.html"><?php echo e($room->title); ?></a></h4>
                
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</aside>
<?php /**PATH F:\Website\walkinroomwavefinal\resources\views/frontsite/partials/leftcontent.blade.php ENDPATH**/ ?>