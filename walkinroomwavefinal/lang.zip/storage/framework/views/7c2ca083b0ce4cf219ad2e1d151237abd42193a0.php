<?php $__env->startSection('content'); ?>
      <!-- Main Container  -->
    <div class="breadcrumbs">
        <div class="container">
          <div class="title-breadcrumb">
           About Us
         </div>
         <ul class="breadcrumb-cate">
          <li><a href="index.html">Home</a></li>
          <li><a href="#">Pages</a></li>
          <li><a href="#">About Us</a></li>
        </ul>
      </div>
    </div>
    <div class="about_us">
      <section class="section-style1">
        <div class="container page-builder-ltr">
          <div class="row row-style row_a1">
            <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12 col_a1c about-text">
              <h3><span>About us</span></h3>
              <p>Our business:</p>
              <ul>
                <li><i class="fa fa-check-circle-o" aria-hidden="true"></i>Hotels</li>
                <li><i class="fa fa-check-circle-o" aria-hidden="true"></i>Employment Placement</li>
                <li><i class="fa fa-check-circle-o" aria-hidden="true"></i>Private Security</li>
                <li><i class="fa fa-check-circle-o" aria-hidden="true"></i>Cleaning Services</li>
                
              </ul>
              <div class="clearfix about-more"><a href="#">Learn more <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a></div>
            </div>
            <div class="col-lg-7 col-md-7 col-sm-6 col-xs-12 col_a1c about-video">
              <div class="ytvideo" data-video="ibuUmMhD2Pg" style="width:870px; height:420px; background-image:url(image/bg-video.jpg)">
                <div class="seo">Travel</div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
    </div>


    <!-- //Main Container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontsite.partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Website\walkinroomwavefinal\resources\views/frontsite/about-us.blade.php ENDPATH**/ ?>