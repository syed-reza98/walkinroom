<!DOCTYPE html>
<html>
<body>
    <h1>Room</h1>

    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <h1><?php echo e($room->title); ?></h1>
       <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h1>Booking</h1>

    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1><?php echo e($booking->check_in); ?></h1>
    <h1><?php echo e($booking->user->name); ?></h1>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h1>Coupon</h1>

    <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <h1><?php echo e($coupon->code); ?></h1>
    <h1><?php echo e($coupon->user->name); ?></h1>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <?php
    $code = $coupons->pluck('code');
    $codearr = $code->toArray();

    $php_array = $codearr;
    $js_array = json_encode($php_array);
    echo "var javascript_array = ". $js_array . ";\n";
    ?>

coupon: <input type="text" name="coupon" id="coupon" value=""><br>
Main C: <input type="text" name="code" id="code" value="<?php echo e($code); ?>"><br>
Field3: <input type="text" id="field3"><br><br>

<button onclick="myFun()">Copy Text</button>

<p>A function is triggered when the button is clicked. The function copies the text from Field1 into Field2.</p>



<p id="demo"></p>


<script>
    function myFun() {
        const numbers = <?php echo(json_encode($php_array)); ?>;
        var coupon = document.getElementById("coupon").value;
        var co;
        let txt = "";
        numbers.forEach(myFunction);
        document.getElementById("demo").innerHTML = co;
        document.getElementById("field3").value = co;
        function myFunction(value, index, array) {
            if(value==coupon){
                txt += value + "Yes<br>";
                co = value;
            }
            else{
                txt += value + "No<br>";
            }
            return co;
        }
    }

</script>


<h1>Hello</h1>

</body>
</html>
<?php /**PATH F:\Website\walkinroomwavefinal\resources\views/frontsite/demo.blade.php ENDPATH**/ ?>