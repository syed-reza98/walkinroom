<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Document</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <input type="text" id="currentDate">
    <script>
    var currentDate = new Date();
    // currentDate = currentDate.toISOString().slice(0, 10);
    // currentDate = currentDate.toLocaleDateString();
    currentDate = `${currentDate.getFullYear()}/${currentDate.getMonth()+1}/${currentDate.getDate()}`;
    document.getElementById("currentDate").value = currentDate;
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type: "POST",
        url: "/check_availability",
        data: { date: currentDate },
        success: function(data) {
        for(let i=0;i<data.length;i++){
                var room = data[i];
                var roomDiv = document.createElement("div");
                roomDiv.innerHTML = "Room Check In: " + room.title;
                document.getElementById("room-list").appendChild(roomDiv);
            }
        }
    });
    </script>
    <div id="room-list"></div>
</body>
</html>
<?php /**PATH F:\check\resources\views/checkindex.blade.php ENDPATH**/ ?>