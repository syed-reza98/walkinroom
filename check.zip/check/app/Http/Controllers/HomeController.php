<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Room;
use App\Models\Roomdate;

class HomeController extends Controller
{
    public function checkAvailability(Request $request) {
        $date = $request->input('date');
        $roomdate = Roomdate::with('room')->where('check_in', '<=', $date)->get();
        $rooms = $roomdate->pluck('room');
        return response()->json($rooms);
    }

    public function checkindex(Request $request) {
        return view('checkindex');
    }
}
